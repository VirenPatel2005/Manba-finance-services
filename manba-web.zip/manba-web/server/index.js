const cors = require('cors');

const express = require('express');
const port = 5000;
const app = express();

const db = require('./config/mongoose')

app.use(express.urlencoded());

app.use(cors());
app.use(express.json());

app.use('/', require('./routes'));

app.listen(port, (err) => {
    if (err) {
        console.log('server listining err : ' + err);
    } else {
        console.log('server start :-' + port);
    }
})