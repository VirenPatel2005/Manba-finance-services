const mongoose = require('mongoose');
mongoose.set('strictQuery', true);

mongoose.connect('mongodb://127.0.0.1/Manba');

const db = mongoose.connection;

db.on('error', console.error.bind(console, ('Db Not Start')));

db.once('open', (err) => {
    if (err) {
        console.log(err);
        return false;
    } else {
        console.log("DB Is Connect");
    }
});

module.exports = db;