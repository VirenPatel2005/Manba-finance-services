const customer = require('../models/customermodel')
const mongoose = require('mongoose');
const nodemailer = require('nodemailer')


module.exports.customerdata = async (req, res) => {
    try {
        let transporter = nodemailer.createTransport({
            service: 'gmail',
            auth: {
                user: 'kishanaravadiya6820@gmail.com',
                pass: 'nyzu xanb efpr jyky'
            }
        });

        let data = await customer.create({
            name: req.body.fname,
            email: req.body.email,
            number: req.body.number,
            city: req.body.city,
            massage: req.body.message,
            loan: req.body.selectedOption
        });

        const { fname, email, number, city, message, selectedOption } = req.body;

        let senderEmail = req.body.email;

        let mailOptions = {
            from: senderEmail,
            to: 'kishanaravadiya6820@gmail.com',
            subject: 'Manba Finaserve Loan',
            html: `<!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta http-equiv="X-UA-Compatible" content="IE=edge">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Email Content</title>
                <style>
                    body {
                        font-family: Arial, sans-serif;
                        background-color: #f5f5f5;
                        padding: 20px;
                    }

                    .container {
                        max-width: 600px;
                        margin: auto;
                        padding: 20px;
                        background-color: white;
                        border-radius: 10px;
                        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
                    }

                    .header {
                        text-align: center;
                        margin-bottom: 20px;
                    }

                    .header h1 {
                        color: #007BFF;
                    }

                    .info-list {
                        list-style-type: none;
                        padding: 0;
                        margin: 0;
                    }

                    .info-list li {
                        margin-bottom: 10px;
                    }

                    .info-label {
                        font-weight: bold;
                        color : Red;
                    }
                </style>
            </head>
            <body>
                <div class="container">
                    <div class="header">
                        <h1>Form Submission Confirmation</h1>
                    </div>
                    <ul class="info-list">
                        <li><span class="info-label">Name:</span> ${fname}</li>
                        <li><span class="info-label">Email:</span> ${email}</li>
                        <li><span class="info-label">Number:</span> ${number}</li>
                        <li><span class="info-label">City:</span> ${city}</li>
                        <li><span class="info-label">Message:</span> ${message}</li>
                        <li><span class="info-label">Loan Type:</span> ${selectedOption}</li>
                    </ul>
                </div>
            </body>
            </html>
            `
        };
        console.log(senderEmail);

        transporter.sendMail(mailOptions, (err, info) => {
            if (err) {
                console.error('Error sending email:', err);
                res.status(400).send({ status: false, Message: "Error sending email", Status: 400 });
            } else {
                console.log('Email sent:', info.response);
                res.status(200).send({ status: true, info: 'Successfully Data Inserted', Message: 'Email sent successfully', Status: 200 });
            }
        });

        if (data) {
            return res.send({ status: true, data: 'SuccessFully Data Inset', Message: 'Done', Status: 200 });
        } else {
            res.send({ status: false, Message: "Record Not Insert", Status: 400 });
            return false;
        }

    }
    catch (err) {
        res.send({ status: false, Message: "Record Not founds", Status: 400 });
        return false;
    }
}

// sgMail.setApiKey('YOUR_SENDGRID_API_KEY');

// app.use(bodyParser.json());

// app.post('/send-email', async (req, res) => {
//   const { fname, email, number, city, message, selectedOption } = req.body;

//   // Assuming this is your customer creation code
//   const data = await customer.create({
//     name: fname,
//     email,
//     number,
//     city,
//     massage: message,
//     loan: selectedOption
//   });

//   const userMailOptions = {
//     to: email,
//     from: 'your-email@example.com',
//     subject: 'Confirmation Email',
//     text: 'Thank you for creating a customer!'
//   };

//   const yourMailOptions = {
//     to: 'your-email@example.com',
//     from: 'your-email@example.com',
//     subject: 'New Customer Created',
//     text: `A new customer has been created:\nName: ${fname}\nEmail: ${email}\nNumber: ${number}\nCity: ${city}\nMessage: ${message}\nLoan: ${selectedOption}`
//   };

//   try {
//     await sgMail.send(userMailOptions);
//     await sgMail.send(yourMailOptions);
//     res.status(200).send('Emails sent successfully.');
//   } catch (error) {
//     console.error('Error sending emails: ', error);
//     res.status(500).send('Error sending emails.');
//   }

// });