const express = require('express');
const routes = express.Router();

const customercontroller = require('../controllers/customercontroller');

routes.post('/customerdata', customercontroller.customerdata);


module.exports = routes;