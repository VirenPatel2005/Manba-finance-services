const express = require('express');

const roturs = express.Router();

roturs.use('/customer',require('./customer'));

module.exports = roturs;